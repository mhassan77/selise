<?php 


/*

	Plugin Name: MCQ Plugin
	Plugin URI: https://wordpress.org
	Description: Let's see
	Author: Selise
	Author URI: https://selise.ch/



*/


define("PLUGIN_DIR_PATH",plugin_dir_path(__FILE__) );
define("PLUGINS_URL", plugins_url());



function add_custom_menu(){
	add_menu_page('MCQ Plugin', 'MCQ Plugin', 'manage_options', 'mcq-plugin', 'mcq_plugin_add_new', '', 9);

	add_submenu_page('mcq-plugin', 'Add New', 'Add New', 'manage_options', 'mcq-plugin', 'mcq_plugin_add_new');
	add_submenu_page('mcq-plugin', 'All Quizes', 'All Quizes', 'manage_options', 'all-quizes', 'mcq_plugin_all_quiz');
}



add_action('admin_menu', 'add_custom_menu');


function mcq_plugin_add_new(){
	echo 'MCQ Quiz Plugin';
	include_once PLUGIN_DIR_PATH.'/views/add-new.php';
}

function mcq_plugin_all_quiz(){
	echo 'All Quiz List';
	include_once PLUGIN_DIR_PATH.'/views/all-quiz.php';
}


function mcq_assests(){
	wp_enqueue_style('style', PLUGINS_URL."/mcq/assets/css/style.css", '', '1.0');

	wp_enqueue_script('script', PLUGINS_URL."/mcq/assets/script/script.js", '', '1.0', true);
}

add_action('wp_enqueue_scripts', 'mcq_assests');



function mcq_plugin_create_table(){
	global $wpdb;
	require_once( ABSPATH. 'wp-admin/includes/upgrade.php');

	 $sql = "CREATE TABLE `wp_mcq_table` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `question` varchar(255) NOT NULL,
        `option1` varchar(255) NOT NULL,
        `option2` varchar(255) NOT NULL,
        `option3` varchar(255) NOT NULL,
        PRIMARY KEY (`id`)
        )
	ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
	dbDelta($sql);
}

register_activation_hook( __FILE__, 'mcq_plugin_create_table' );


?>


